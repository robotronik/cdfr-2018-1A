commande pour supprimer tous les fichiers *.fcstd1:
#find -name "*.fcstd1"|xargs rm
